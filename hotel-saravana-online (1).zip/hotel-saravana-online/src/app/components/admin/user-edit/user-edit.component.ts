import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {first} from "rxjs/operators";
import { FoodserviceService } from "./../../../services/foodservice.service";

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {
  _id: any
  username: any
  emailid: any
  phoneno1: any
  phoneno2: any
  address: any
  password: any
  password8: any
 

  constructor(private route: ActivatedRoute, private foodService: FoodserviceService, private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['id'];
      console.log(this._id);
    })
    this.foodService.getUserById(this._id)
      .subscribe( data1 => {
        console.log(data1)
        this.username = data1.username;
        this.address=data1.address;
        this.phoneno1=data1.phoneno1;
        this.phoneno2=data1.phoneno2;
        this.emailid  = data1.emailid;
        this.password = data1.password;
      },
      error => {
        alert(error);
      });
  }
  editUser() {
    var body = "_id=" + this._id 
        + "&username=" + this.username 
        + "&address=" + this.address
        + "&phoneno1=" + this.phoneno1
        + "&phoneno2=" + this.phoneno2
        + "&emailid=" + this.emailid 
        + "&password=" + this.password;
    // console.log(body)
    this.foodService.updateUser(body,this._id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['user-list']);
        },
        error => {
          alert(error);
        });
  }

}
