import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from "@angular/router";
import { ItemService } from './../../../services/item.service';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-item-add',
  templateUrl: './item-add.component.html',
  styleUrls: ['./item-add.component.css']
})
export class ItemAddComponent implements OnInit {

  itemname: any
  itemdesc: any
  price: any
  message = ''
  uploadedFiles:Array <File>=[];

  constructor(private router:Router, private itemService:ItemService, private elementRef:ElementRef,
    private http:HttpClient) { }

  ngOnInit(): void {
  }
  fileChange(element:any) {
    this.uploadedFiles = element.target.files;
  }

  addItem () {
    let inputEl = this.elementRef.nativeElement.querySelector('#file1');
    var formData = new FormData();
    formData.append("itemname", this.itemname);
    formData.append("itemdesc", this.itemdesc);
    formData.append("price",    this.price);
    formData.append('file1', inputEl.files.item(0) );
  
    this.itemService.createItem(formData).subscribe(
      result => {
        this.router.navigate(['item-list']);
      },
      error => {
        //this.message = error.error
        alert('Error while Adding an Item!')
      });
  }

  clearMessage() {
    this.message = ''
  }

}
